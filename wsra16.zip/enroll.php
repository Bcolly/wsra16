<?php
$izena= $_POST['izena'];
$adina= $ POST['abizena1'];
echo ("Kaixo $izena , $adina urte dituzu");
/*
//$niremysqli = new mysqli("localhost", "root", "quiz");
$niremysqli = new mysqli("localhost", "root", "", "Quiz");
//(“hostinger_aterpea, “hostinger_erab", “pasahitza", “db_izena");

//konexioa zabaldu
if ($niremysqli->connect_errno) {
	echo "Huts egin du konexioak MySQL-ra: (" . $niremysqli-> connect_errno . ") " . $niremysqli-> connect_error;
}

echo $niremysqli->host_info . "\n";

/*
//$sql = "INSERT INTO erabiltzailea(Izena, Abizena1, Abizena2, PostaElektronikoa, Sexua, Pasahitza, TelefonoZbkia, Espezialitatea, Interesak)
//VALUES ('$_POST[izena]' , '$_POST[abizena1]' , '$_POST[abizena2]' , '$_POST[maila]' , '$_POST[sex]' , '$_POST[pass]' , '$_POST[telf]' , '$_POST[espezialitatea]' , '$_POST[interes]')";

$sql = "INSERT INTO erabiltzailea(Izena, Abizena1, Abizena2, PostaElektronikoa, Sexua, Pasahitza, TelefonoZbkia, Espezialitatea, Interesak)\n"
    . "VALUES (\'$_POST[izena]\' , \'$_POST[abizena1]\' , \'$_POST[abizena2]\' , \'$_POST[maila]\' , \'$_POST[sex]\' , \'$_POST[pass]\' , \'$_POST[telf]\' , \'$_POST[espezialitatea]\' , \'$_POST[interes]\')";

	if (!$niremysqli->query($sql)){
	echo "Taularen sorrerak huts egin: (" .
	$mysqli->errno . ") " . $mysqli->error;
	//die('Errorea: ' . $niremysqli->error);
}
else { echo "OK";}

echo "Erregistro bat gehitu da!";
<p> <a href='showUsers.php'> Erregistroak ikusi</a> </p>
// Konexioa itxi
$niremysqli->close();*/
?>