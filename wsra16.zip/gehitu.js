function gehitu(){
	
	var aux = document.getElementById("espezialitatea");
	var y = document.getElementById("testua");
		if(aux.value == "Besterik"){
			y.style.display = "inline";
		}
		else{y.style.display = "none";}
}
